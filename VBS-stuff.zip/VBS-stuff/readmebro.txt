Ah hello to the one who is reading this...! 
These files are just stupid VBScript files, and relax, they aren't viruses. 

=====================================================================================================

> The "Annoying & Prank" folder contents files that are annoying, like fake "viruses", and even files to prank.
> The "Useful" folder contents files that can... be useful (just like it's name lmao)   

P.S: To end any file provided just click on the file "Kill Wscript.exe [You will need this bro].bat"
=====================================================================================================

Credits:
[AJW]

=====================================================================================================

Oh and, don't forget to check my website!! 
[ https://sites.google.com/view/ajw-cmd-system ]